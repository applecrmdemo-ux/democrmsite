/**
 * Repair ticket model - device, serial, issue, status, technician notes, customer ref
 */

const mongoose = require('mongoose');

const repairSchema = new mongoose.Schema(
  {
    deviceName: { type: String, required: true, trim: true },
    serialNumber: { type: String, trim: true },
    issueDescription: { type: String, default: '' },
    status: {
      type: String,
      enum: ['Pending', 'In Progress', 'Completed'],
      default: 'Pending',
    },
    technicianNotes: { type: String, default: '' },
    amount: { type: Number, default: 0, min: 0 },
    customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Repair', repairSchema);
