/**
 * Appointment model - customer name, date, time, purpose
 */

const mongoose = require('mongoose');

const appointmentSchema = new mongoose.Schema(
  {
    customerName: { type: String, required: true, trim: true },
    date: { type: Date, required: true },
    time: { type: String, required: true, trim: true },
    purpose: { type: String, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Appointment', appointmentSchema);
