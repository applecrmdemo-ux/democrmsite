/**
 * Server configuration - single source of truth for env and constants.
 * Load env first (dotenv) then expose PORT and MONGODB_URI.
 */

try {
  require('dotenv').config();
} catch (_) {
  // dotenv optional when env vars set externally
}

const PORT = Number(process.env.PORT) || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/crm-demo';

module.exports = {
  PORT,
  MONGODB_URI,
};
