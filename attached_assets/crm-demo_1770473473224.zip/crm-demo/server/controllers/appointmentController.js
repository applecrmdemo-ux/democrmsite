/**
 * Appointments - create, list
 */

const Appointment = require('../models/Appointment');

async function list(req, res, next) {
  try {
    const appointments = await Appointment.find().sort({ date: 1, time: 1 }).lean();
    res.json(appointments);
  } catch (err) {
    next(err);
  }
}

async function getOne(req, res, next) {
  try {
    const appointment = await Appointment.findById(req.params.id).lean();
    if (!appointment) return res.status(404).json({ error: 'Appointment not found' });
    res.json(appointment);
  } catch (err) {
    next(err);
  }
}

async function create(req, res, next) {
  try {
    const { customerName, date, time, purpose } = req.body;
    if (!customerName || !customerName.trim()) return res.status(400).json({ error: 'Customer name is required' });
    if (!date) return res.status(400).json({ error: 'Date is required' });
    if (!time || !time.trim()) return res.status(400).json({ error: 'Time is required' });
    const appointment = await Appointment.create({
      customerName: customerName.trim(),
      date: new Date(date),
      time: time.trim(),
      purpose: purpose || '',
    });
    res.status(201).json(appointment);
  } catch (err) {
    next(err);
  }
}

async function update(req, res, next) {
  try {
    const { customerName, date, time, purpose } = req.body;
    const update = {};
    if (customerName != null) update.customerName = customerName.trim();
    if (date != null) update.date = new Date(date);
    if (time != null) update.time = time.trim();
    if (purpose != null) update.purpose = purpose;
    const appointment = await Appointment.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true }).lean();
    if (!appointment) return res.status(404).json({ error: 'Appointment not found' });
    res.json(appointment);
  } catch (err) {
    next(err);
  }
}

async function remove(req, res, next) {
  try {
    const appointment = await Appointment.findByIdAndDelete(req.params.id);
    if (!appointment) return res.status(404).json({ error: 'Appointment not found' });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

module.exports = { list, getOne, create, update, remove };
