/**
 * Product CRUD and stock update
 */

const Product = require('../models/Product');

async function list(req, res, next) {
  try {
    const products = await Product.find().sort({ createdAt: -1 }).lean();
    res.json(products);
  } catch (err) {
    next(err);
  }
}

async function getOne(req, res, next) {
  try {
    const product = await Product.findById(req.params.id).lean();
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (err) {
    next(err);
  }
}

async function create(req, res, next) {
  try {
    const { name, category, price, stock } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required' });
    const numPrice = Number(price);
    const numStock = Number(stock);
    if (isNaN(numPrice) || numPrice < 0) return res.status(400).json({ error: 'Valid price is required' });
    if (isNaN(numStock) || numStock < 0) return res.status(400).json({ error: 'Valid stock is required' });
    const product = await Product.create({
      name: name.trim(),
      category: category || '',
      price: numPrice,
      stock: numStock,
    });
    res.status(201).json(product);
  } catch (err) {
    next(err);
  }
}

async function update(req, res, next) {
  try {
    const { name, category, price, stock } = req.body;
    const update = {};
    if (name != null) update.name = name.trim();
    if (category != null) update.category = category;
    if (price != null) {
      const num = Number(price);
      if (isNaN(num) || num < 0) return res.status(400).json({ error: 'Invalid price' });
      update.price = num;
    }
    if (stock != null) {
      const num = Number(stock);
      if (isNaN(num) || num < 0) return res.status(400).json({ error: 'Invalid stock' });
      update.stock = num;
    }
    const product = await Product.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true }).lean();
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (err) {
    next(err);
  }
}

async function remove(req, res, next) {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

module.exports = { list, getOne, create, update, remove };
