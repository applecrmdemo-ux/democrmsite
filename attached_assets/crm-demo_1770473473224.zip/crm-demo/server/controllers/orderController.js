/**
 * Orders - list (populate customer + items.product), create (compute total from product prices)
 */

const Order = require('../models/Order');
const Product = require('../models/Product');

async function list(req, res, next) {
  try {
    const orders = await Order.find()
      .populate('customer', 'name email phone')
      .populate('items.product', 'name price')
      .sort({ createdAt: -1 })
      .lean();
    res.json(orders);
  } catch (err) {
    next(err);
  }
}

async function getOne(req, res, next) {
  try {
    const order = await Order.findById(req.params.id)
      .populate('customer', 'name email phone')
      .populate('items.product', 'name price')
      .lean();
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json(order);
  } catch (err) {
    next(err);
  }
}

async function create(req, res, next) {
  try {
    const { customer, items } = req.body;
    if (!customer) return res.status(400).json({ error: 'Customer is required' });
    if (!items || !Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'At least one item is required' });

    let total = 0;
    const resolvedItems = [];
    for (const it of items) {
      const product = await Product.findById(it.product).lean();
      if (!product) return res.status(400).json({ error: `Product not found: ${it.product}` });
      const qty = Math.max(1, Number(it.quantity) || 1);
      resolvedItems.push({ product: product._id, quantity: qty });
      total += product.price * qty;
    }

    const order = await Order.create({ customer, items: resolvedItems, total });
    const populated = await Order.findById(order._id)
      .populate('customer', 'name email phone')
      .populate('items.product', 'name price')
      .lean();
    res.status(201).json(populated);
  } catch (err) {
    next(err);
  }
}

module.exports = { list, getOne, create };
