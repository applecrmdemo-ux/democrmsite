/**
 * Repair tickets - create, list, get one, update status/notes
 */

const Repair = require('../models/Repair');

async function list(req, res, next) {
  try {
    const repairs = await Repair.find().populate('customer', 'name phone email').sort({ createdAt: -1 }).lean();
    res.json(repairs);
  } catch (err) {
    next(err);
  }
}

async function getOne(req, res, next) {
  try {
    const repair = await Repair.findById(req.params.id).populate('customer', 'name phone email').lean();
    if (!repair) return res.status(404).json({ error: 'Repair not found' });
    res.json(repair);
  } catch (err) {
    next(err);
  }
}

async function create(req, res, next) {
  try {
    const { deviceName, serialNumber, issueDescription, status, technicianNotes, customer, amount } = req.body;
    if (!deviceName || !deviceName.trim()) return res.status(400).json({ error: 'Device name is required' });
    const repair = await Repair.create({
      deviceName: deviceName.trim(),
      serialNumber: serialNumber || '',
      issueDescription: issueDescription || '',
      status: status || 'Pending',
      technicianNotes: technicianNotes || '',
      amount: amount != null ? Number(amount) : 0,
      customer: customer || undefined,
    });
    const populated = await Repair.findById(repair._id).populate('customer', 'name phone email').lean();
    res.status(201).json(populated);
  } catch (err) {
    next(err);
  }
}

async function update(req, res, next) {
  try {
    const { deviceName, serialNumber, issueDescription, status, technicianNotes, customer, amount } = req.body;
    const update = {};
    if (deviceName != null) update.deviceName = deviceName.trim();
    if (serialNumber != null) update.serialNumber = serialNumber;
    if (issueDescription != null) update.issueDescription = issueDescription;
    if (status != null) update.status = status;
    if (technicianNotes != null) update.technicianNotes = technicianNotes;
    if (customer != null) update.customer = customer;
    if (amount != null) update.amount = Number(amount);
    const repair = await Repair.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true })
      .populate('customer', 'name phone email')
      .lean();
    if (!repair) return res.status(404).json({ error: 'Repair not found' });
    res.json(repair);
  } catch (err) {
    next(err);
  }
}

async function remove(req, res, next) {
  try {
    const repair = await Repair.findByIdAndDelete(req.params.id);
    if (!repair) return res.status(404).json({ error: 'Repair not found' });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

module.exports = { list, getOne, create, update, remove };
