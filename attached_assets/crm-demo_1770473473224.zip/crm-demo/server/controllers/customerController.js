/**
 * Customer CRUD - add, list, get one, update, delete
 */

const Customer = require('../models/Customer');

async function list(req, res, next) {
  try {
    const customers = await Customer.find().sort({ createdAt: -1 }).lean();
    res.json(customers);
  } catch (err) {
    next(err);
  }
}

async function getOne(req, res, next) {
  try {
    const customer = await Customer.findById(req.params.id).lean();
    if (!customer) return res.status(404).json({ error: 'Customer not found' });
    res.json(customer);
  } catch (err) {
    next(err);
  }
}

async function create(req, res, next) {
  try {
    const { name, phone, email, notes } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required' });
    const customer = await Customer.create({ name: name.trim(), phone: phone || '', email: email || '', notes: notes || '' });
    res.status(201).json(customer);
  } catch (err) {
    next(err);
  }
}

async function update(req, res, next) {
  try {
    const { name, phone, email, notes } = req.body;
    const customer = await Customer.findByIdAndUpdate(
      req.params.id,
      { name: name != null ? name.trim() : undefined, phone, email, notes },
      { new: true, runValidators: true }
    ).lean();
    if (!customer) return res.status(404).json({ error: 'Customer not found' });
    res.json(customer);
  } catch (err) {
    next(err);
  }
}

async function remove(req, res, next) {
  try {
    const customer = await Customer.findByIdAndDelete(req.params.id);
    if (!customer) return res.status(404).json({ error: 'Customer not found' });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

module.exports = { list, getOne, create, update, remove };
