/**
 * Dashboard stats - total customers, products, active repairs, today revenue
 */

const Customer = require('../models/Customer');
const Product = require('../models/Product');
const Repair = require('../models/Repair');
const Order = require('../models/Order');

async function getStats(req, res, next) {
  try {
    const [totalCustomers, totalProducts, totalOrders, activeRepairs, todayRevenue] = await Promise.all([
      Customer.countDocuments(),
      Product.countDocuments(),
      Order.countDocuments(),
      Repair.countDocuments({ status: { $in: ['Pending', 'In Progress'] } }),
      (() => {
        const start = new Date();
        start.setHours(0, 0, 0, 0);
        const end = new Date(start);
        end.setDate(end.getDate() + 1);
        return Repair.aggregate([
          { $match: { status: 'Completed', updatedAt: { $gte: start, $lt: end } } },
          { $group: { _id: null, total: { $sum: '$amount' } } },
        ]).then((r) => (r[0] ? r[0].total : 0));
      })(),
    ]);
    res.json({
      totalCustomers,
      totalProducts,
      totalOrders,
      activeRepairs,
      todayRevenue: Number(todayRevenue) || 0,
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { getStats };
