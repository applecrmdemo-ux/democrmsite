/**
 * CRM Demo - Server entry point.
 * Single startup flow: load config -> connect MongoDB -> start Express.
 * Database is created automatically by MongoDB when first used.
 */

const mongoose = require('mongoose');
const { PORT, MONGODB_URI } = require('./config');
const app = require('./app');

async function start() {
  try {
    await mongoose.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 10000,
    });
    console.log('[MongoDB] Connected to', mongoose.connection.name || 'crm-demo');

    const server = app.listen(PORT, () => {
      console.log('[Server] Listening on http://localhost:' + PORT);
    });

    server.on('error', (err) => {
      console.error('[Server] Listen error:', err.message);
      process.exit(1);
    });

    const shutdown = () => {
      server.close(() => {
        mongoose.connection.close(false).then(() => {
          console.log('[Server] Shutdown complete');
          process.exit(0);
        }).catch((err) => {
          console.error('[Server] Mongo close error:', err.message);
          process.exit(1);
        });
      });
    };
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  } catch (err) {
    console.error('[MongoDB] Connection failed:', err.message);
    process.exit(1);
  }
}

start();
