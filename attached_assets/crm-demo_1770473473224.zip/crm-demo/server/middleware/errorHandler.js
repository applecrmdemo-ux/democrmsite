/**
 * Global error handler - consistent JSON responses and proper status codes.
 * Handles Mongoose CastError (invalid id) and ValidationError.
 */

function errorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err);
  }

  let status = 500;
  let message = err.message || 'Internal server error';

  if (err.name === 'CastError') {
    status = 400;
    message = 'Invalid id format';
  } else if (err.name === 'ValidationError') {
    status = 400;
    message = err.message;
  } else if (err.statusCode && err.statusCode >= 400 && err.statusCode < 600) {
    status = err.statusCode;
  }

  if (status === 500) {
    console.error('[Error]', err.message);
  }

  res.status(status).json({ error: message });
}

module.exports = errorHandler;
