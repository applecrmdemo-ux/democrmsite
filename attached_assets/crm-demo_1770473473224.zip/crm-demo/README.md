# CRM Demo – Apple-style electronics retail store

Full-stack demo CRM: **React (Vite) + Tailwind + Axios** frontend and **Node.js + Express + MongoDB (Mongoose)** backend.

## Prerequisites

- **Node.js** (v18+)
- **MongoDB** running locally (e.g. `mongodb://127.0.0.1:27017`) or set `MONGODB_URI` in `server/.env`

## Project structure

```
crm-demo/
├── client/                 # React frontend
│   ├── src/
│   │   ├── api/client.js   # Axios API client
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   ├── index.css
│   │   └── pages/
│   │       ├── Dashboard.jsx
│   │       ├── Customers.jsx
│   │       ├── Products.jsx
│   │       ├── Repairs.jsx
│   │       └── Appointments.jsx
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── postcss.config.js
├── server/                 # Express backend
│   ├── index.js            # Entry: DB connect + start server
│   ├── app.js               # Express app, CORS, routes
│   ├── package.json
│   ├── middleware/
│   │   └── errorHandler.js
│   ├── models/
│   │   ├── Customer.js
│   │   ├── Product.js
│   │   ├── Repair.js
│   │   └── Appointment.js
│   ├── controllers/
│   │   ├── customerController.js
│   │   ├── productController.js
│   │   ├── repairController.js
│   │   ├── appointmentController.js
│   │   └── dashboardController.js
│   └── routes/
│       ├── customerRoutes.js
│       ├── productRoutes.js
│       ├── repairRoutes.js
│       ├── appointmentRoutes.js
│       └── dashboardRoutes.js
└── README.md
```

## Install and run

### 1. Backend

```bash
cd server
npm install
npm start
```

Server runs at **http://localhost:5000**. Uses MongoDB at `mongodb://127.0.0.1:27017/crm-demo` unless you set `MONGODB_URI` in `server/.env` (copy from `server/.env.example`).

### 2. Frontend

In a second terminal:

```bash
cd client
npm install
npm run dev
```

App runs at **http://localhost:5173**.

### 3. Use the app

- Open **http://localhost:5173** in the browser.
- Use the sidebar: **Dashboard**, **Customers**, **Products**, **Repairs**, **Appointments**.
- Add/edit/delete data; dashboard stats (customers, products, active repairs, today revenue) load from the API.

## API endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/dashboard/stats | Dashboard counts + today revenue |
| GET/POST | /api/customers | List, create |
| GET/PUT/DELETE | /api/customers/:id | Get, update, delete customer |
| GET/POST | /api/products | List, create |
| GET/PUT/DELETE | /api/products/:id | Get, update, delete product |
| GET/POST | /api/repairs | List, create |
| GET/PUT/DELETE | /api/repairs/:id | Get, update, delete repair |
| GET/POST | /api/appointments | List, create |
| GET/PUT/DELETE | /api/appointments/:id | Get, update, delete appointment |

No authentication; for demo use only.
