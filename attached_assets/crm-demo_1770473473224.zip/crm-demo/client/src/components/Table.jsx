/**
 * Reusable table wrapper - consistent styling for data tables.
 * columns: [{ key, label, className? }], children: <tr> rows
 */
export default function Table({ columns, children, emptyMessage = 'No data yet.' }) {
  const hasRows = Array.isArray(children) ? children.length > 0 : !!children;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left">
        <thead>
          <tr className="border-b border-slate-200">
            {columns.map((col) => (
              <th
                key={col.key}
                className={`pb-3 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider ${col.className || ''}`}
              >
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {children}
        </tbody>
      </table>
      {!hasRows && emptyMessage && (
        <p className="py-8 text-center text-slate-500">{emptyMessage}</p>
      )}
    </div>
  );
}
