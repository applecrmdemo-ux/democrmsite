export default function Navbar({ title }) {
  return (
    <header className="h-14 border-b border-slate-200 bg-white px-6 flex items-center justify-between shadow-sm">
      <h1 className="text-lg font-semibold text-slate-800">{title}</h1>
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 text-sm font-medium">
          U
        </div>
        <span className="text-sm text-slate-500 hidden sm:inline">User</span>
      </div>
    </header>
  );
}
