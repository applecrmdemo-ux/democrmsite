/**
 * API service layer - all backend calls in one place.
 */

import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
});

// Dashboard
export function getDashboardStats() {
  return api.get('/dashboard/stats').then((res) => res.data);
}

// Customers
export function getCustomers() {
  return api.get('/customers').then((res) => res.data);
}
export function createCustomer(data) {
  return api.post('/customers', data).then((res) => res.data);
}
export function updateCustomer(id, data) {
  return api.put(`/customers/${id}`, data).then((res) => res.data);
}
export function deleteCustomer(id) {
  return api.delete(`/customers/${id}`);
}

// Products
export function getProducts() {
  return api.get('/products').then((res) => res.data);
}
export function createProduct(data) {
  return api.post('/products', data).then((res) => res.data);
}
export function updateProduct(id, data) {
  return api.put(`/products/${id}`, data).then((res) => res.data);
}
export function deleteProduct(id) {
  return api.delete(`/products/${id}`);
}

// Orders
export function getOrders() {
  return api.get('/orders').then((res) => res.data);
}
export function createOrder(data) {
  return api.post('/orders', data).then((res) => res.data);
}
