import { useState, useEffect } from 'react';
import { getProducts, createProduct, updateProduct, deleteProduct } from '../api/api';
import Card from '../components/Card';

export default function Products() {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({ name: '', category: '', price: '', stock: '' });

  const fetchList = () => {
    setLoading(true);
    getProducts()
      .then(setList)
      .catch((err) => setError(err.response?.data?.error || err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => fetchList(), []);

  const openAdd = () => {
    setForm({ name: '', category: '', price: '', stock: '' });
    setModal('add');
  };

  const openEdit = (p) => {
    setForm({ name: p.name, category: p.category || '', price: p.price, stock: p.stock });
    setModal({ id: p._id });
  };

  const closeModal = () => setModal(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    const payload = { ...form, price: Number(form.price), stock: Number(form.stock) };
    setError(null);
    const promise = modal === 'add'
      ? createProduct(payload)
      : updateProduct(modal.id, payload);
    promise
      .then(() => { closeModal(); fetchList(); })
      .catch((err) => setError(err.response?.data?.error || err.message));
  };

  const handleDelete = (id) => {
    if (!window.confirm('Delete this product?')) return;
    setError(null);
    deleteProduct(id)
      .then(() => fetchList())
      .catch((err) => setError(err.response?.data?.error || err.message));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="text-slate-600">Manage inventory and product catalog.</p>
        <button
          type="button"
          onClick={openAdd}
          className="px-4 py-2 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-700 shadow-sm"
        >
          Add Product
        </button>
      </div>

      {error && (
        <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-red-700 text-sm">
          {error}
        </div>
      )}

      <Card>
        {loading ? (
          <p className="text-slate-500 py-8 text-center">Loading…</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="pb-3 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Name</th>
                  <th className="pb-3 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Category</th>
                  <th className="pb-3 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Price</th>
                  <th className="pb-3 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Stock</th>
                  <th className="pb-3 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {list.map((p) => (
                  <tr key={p._id} className="hover:bg-slate-50/50">
                    <td className="py-3 pr-4 font-medium text-slate-800">{p.name}</td>
                    <td className="py-3 pr-4 text-slate-600">{p.category || '—'}</td>
                    <td className="py-3 pr-4 text-slate-600">${Number(p.price).toFixed(2)}</td>
                    <td className="py-3 pr-4 text-slate-600">{p.stock}</td>
                    <td className="py-3 text-right flex gap-2 justify-end">
                      <button
                        type="button"
                        onClick={() => openEdit(p)}
                        className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(p._id)}
                        className="text-red-600 hover:text-red-700 text-sm font-medium"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {list.length === 0 && (
              <p className="py-8 text-center text-slate-500">No products yet. Add one to get started.</p>
            )}
          </div>
        )}
      </Card>

      {modal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={closeModal}>
          <Card className="max-w-md w-full shadow-xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-slate-800 mb-4">
              {modal === 'add' ? 'Add Product' : 'Edit Product'}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Name *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:ring-2 focus:ring-slate-400 focus:border-slate-400"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                <input
                  type="text"
                  value={form.category}
                  onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:ring-2 focus:ring-slate-400 focus:border-slate-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Price *</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={form.price}
                  onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:ring-2 focus:ring-slate-400 focus:border-slate-400"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Stock *</label>
                <input
                  type="number"
                  min="0"
                  value={form.stock}
                  onChange={(e) => setForm((f) => ({ ...f, stock: e.target.value }))}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:ring-2 focus:ring-slate-400 focus:border-slate-400"
                  required
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={closeModal} className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50">
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700">
                  Save
                </button>
              </div>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
}
