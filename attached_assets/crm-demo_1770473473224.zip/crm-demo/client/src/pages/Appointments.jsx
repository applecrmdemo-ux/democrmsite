import { useState, useEffect } from 'react';
import api from '../api/client';

function formatDate(d) {
  if (!d) return '—';
  const x = new Date(d);
  return x.toLocaleDateString();
}

export default function Appointments() {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({ customerName: '', date: '', time: '', purpose: '' });

  const fetchList = () => {
    setLoading(true);
    api.get('/appointments').then((res) => setList(res.data)).catch((err) => setError(err.response?.data?.error || err.message)).finally(() => setLoading(false));
  };

  useEffect(() => fetchList(), []);

  const openAdd = () => {
    const today = new Date().toISOString().slice(0, 10);
    setForm({ customerName: '', date: today, time: '10:00', purpose: '' });
    setModal('add');
  };

  const openEdit = (a) => {
    const d = new Date(a.date);
    setForm({
      customerName: a.customerName,
      date: d.toISOString().slice(0, 10),
      time: a.time || '10:00',
      purpose: a.purpose || '',
    });
    setModal({ id: a._id });
  };

  const closeModal = () => setModal(null);

  const submit = (e) => {
    e.preventDefault();
    if (!form.customerName.trim() || !form.date || !form.time) return;
    const promise = modal === 'add' ? api.post('/appointments', form) : api.put(`/appointments/${modal.id}`, form);
    promise.then(() => { closeModal(); fetchList(); }).catch((err) => setError(err.response?.data?.error || err.message));
  };

  const deleteAppointment = (id) => {
    if (!window.confirm('Delete this appointment?')) return;
    api.delete(`/appointments/${id}`).then(() => fetchList()).catch((err) => setError(err.response?.data?.error || err.message));
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Appointments</h1>
        <button onClick={openAdd} className="bg-gray-900 text-white px-4 py-2 rounded-md hover:bg-gray-800">New Booking</button>
      </div>
      {error && <p className="text-red-600 mb-4">{error}</p>}
      {loading ? (
        <p className="text-gray-500">Loading…</p>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Purpose</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {list.map((a) => (
                <tr key={a._id}>
                  <td className="px-4 py-3 text-sm">{a.customerName}</td>
                  <td className="px-4 py-3 text-sm">{formatDate(a.date)}</td>
                  <td className="px-4 py-3 text-sm">{a.time}</td>
                  <td className="px-4 py-3 text-sm max-w-xs truncate">{a.purpose || '—'}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => openEdit(a)} className="text-blue-600 hover:underline mr-3">Edit</button>
                    <button onClick={() => deleteAppointment(a._id)} className="text-red-600 hover:underline">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {list.length === 0 && <p className="p-4 text-gray-500 text-center">No appointments yet.</p>}
        </div>
      )}

      {modal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-10" onClick={closeModal}>
          <div className="bg-white rounded-lg p-6 w-full max-w-md shadow-xl" onClick={(e) => e.stopPropagation()}>
            <h2 className="text-lg font-semibold mb-4">{modal === 'add' ? 'New Booking' : 'Edit Appointment'}</h2>
            <form onSubmit={submit}>
              <label className="block text-sm font-medium text-gray-700 mb-1">Customer name *</label>
              <input type="text" value={form.customerName} onChange={(e) => setForm((f) => ({ ...f, customerName: e.target.value }))} className="w-full border rounded px-3 py-2 mb-3" required />
              <label className="block text-sm font-medium text-gray-700 mb-1">Date *</label>
              <input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} className="w-full border rounded px-3 py-2 mb-3" required />
              <label className="block text-sm font-medium text-gray-700 mb-1">Time *</label>
              <input type="time" value={form.time} onChange={(e) => setForm((f) => ({ ...f, time: e.target.value }))} className="w-full border rounded px-3 py-2 mb-3" required />
              <label className="block text-sm font-medium text-gray-700 mb-1">Purpose</label>
              <input type="text" value={form.purpose} onChange={(e) => setForm((f) => ({ ...f, purpose: e.target.value }))} className="w-full border rounded px-3 py-2 mb-4" />
              <div className="flex justify-end gap-2">
                <button type="button" onClick={closeModal} className="px-4 py-2 border rounded hover:bg-gray-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-gray-900 text-white rounded hover:bg-gray-800">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
