import { useState, useEffect } from 'react';
import { getOrders, createOrder, getCustomers, getProducts } from '../api/api';
import Card from '../components/Card';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ customer: '', items: [{ product: '', quantity: 1 }] });

  const fetchOrders = () => {
    setLoading(true);
    getOrders()
      .then(setOrders)
      .catch((err) => setError(err.response?.data?.error || err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchOrders();
    getCustomers().then(setCustomers).catch(() => {});
    getProducts().then(setProducts).catch(() => {});
  }, []);

  const handleAddLine = () => {
    setForm((f) => ({ ...f, items: [...f.items, { product: '', quantity: 1 }] }));
  };

  const handleRemoveLine = (index) => {
    setForm((f) => ({
      ...f,
      items: f.items.filter((_, i) => i !== index),
    }));
  };

  const handleLineChange = (index, field, value) => {
    setForm((f) => ({
      ...f,
      items: f.items.map((item, i) =>
        i === index ? { ...item, [field]: field === 'quantity' ? Math.max(1, Number(value) || 1) : value } : item
      ),
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.customer) {
      setError('Select a customer.');
      return;
    }
    const validItems = form.items.filter((i) => i.product);
    if (validItems.length === 0) {
      setError('Add at least one product.');
      return;
    }
    setError(null);
    createOrder({ customer: form.customer, items: validItems })
      .then(() => {
        setShowForm(false);
        setForm({ customer: '', items: [{ product: '', quantity: 1 }] });
        fetchOrders();
      })
      .catch((err) => setError(err.response?.data?.error || err.message));
  };

  const formatDate = (d) => (d ? new Date(d).toLocaleDateString() : '—');

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="text-slate-600">View and create orders linked to customers and products.</p>
        <button
          type="button"
          onClick={() => setShowForm(true)}
          className="px-4 py-2 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-700 shadow-sm"
        >
          Create Order
        </button>
      </div>

      {error && (
        <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-red-700 text-sm">
          {error}
        </div>
      )}

      <Card title="Orders">
        {loading ? (
          <p className="text-slate-500 py-8 text-center">Loading…</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="pb-3 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Date</th>
                  <th className="pb-3 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Customer</th>
                  <th className="pb-3 pr-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Items</th>
                  <th className="pb-3 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map((ord) => (
                  <tr key={ord._id} className="hover:bg-slate-50/50">
                    <td className="py-3 pr-4 text-slate-600">{formatDate(ord.createdAt)}</td>
                    <td className="py-3 pr-4 font-medium text-slate-800">{ord.customer?.name ?? '—'}</td>
                    <td className="py-3 pr-4 text-slate-600">
                      {ord.items?.length
                        ? ord.items.map((i) => `${i.product?.name ?? 'Product'} × ${i.quantity}`).join(', ')
                        : '—'}
                    </td>
                    <td className="py-3 text-right font-medium text-slate-800">${Number(ord.total).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {orders.length === 0 && (
              <p className="py-8 text-center text-slate-500">No orders yet. Create one to get started.</p>
            )}
          </div>
        )}
      </Card>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4 overflow-y-auto" onClick={() => setShowForm(false)}>
          <Card className="max-w-lg w-full shadow-xl my-8" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Create Order</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Customer *</label>
                <select
                  value={form.customer}
                  onChange={(e) => setForm((f) => ({ ...f, customer: e.target.value }))}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:ring-2 focus:ring-slate-400 focus:border-slate-400"
                  required
                >
                  <option value="">Select customer</option>
                  {customers.map((c) => (
                    <option key={c._id} value={c._id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-slate-700">Items *</label>
                  <button type="button" onClick={handleAddLine} className="text-sm text-blue-600 hover:text-blue-700">
                    + Add line
                  </button>
                </div>
                <div className="space-y-2">
                  {form.items.map((item, index) => (
                    <div key={index} className="flex gap-2 items-center">
                      <select
                        value={item.product}
                        onChange={(e) => handleLineChange(index, 'product', e.target.value)}
                        className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-slate-800 text-sm focus:ring-2 focus:ring-slate-400"
                      >
                        <option value="">Select product</option>
                        {products.map((p) => (
                          <option key={p._id} value={p._id}>{p.name} — ${Number(p.price).toFixed(2)}</option>
                        ))}
                      </select>
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => handleLineChange(index, 'quantity', e.target.value)}
                        className="w-20 rounded-lg border border-slate-300 px-2 py-2 text-sm text-slate-800"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemoveLine(index)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded"
                        aria-label="Remove line"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700">
                  Create Order
                </button>
              </div>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
}
